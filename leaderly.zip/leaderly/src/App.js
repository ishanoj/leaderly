import bg from './leaderlyBG.png';
import lg from './leaderlyLG.png';

import React, { Fragment } from "react";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Image from 'react-bootstrap/Image';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Button from 'react-bootstrap/Button';

import './App.css';

function App() {
  return (
    <Fragment>
      <Navbar bg="dark" data-bs-theme="dark">
        <Container>
          <Navbar.Brand href="#home">
          <Image
            src={lg}
            alt="Leaderly Logo"
            thumbnail 
          />
          </Navbar.Brand>
          <Nav>
          <Navbar.Brand href="#home">
          <svg
            fill="#F65526"
            width="25px"
            height="25px"
            viewBox="0 0 24 24"
            className='mt-2'
          >
          <path d="M10,20h4a2,2,0,0,1-4,0Zm8-4V10a6,6,0,0,0-5-5.91V3a1,1,0,0,0-2,0V4.09A6,6,0,0,0,6,10v6L4,18H20Z" />
          </svg>
          </Navbar.Brand>
            <NavDropdown title={UserMenu} id="collapsible-nav-dropdown">
              <NavDropdown.Item href="#action/3.1">User Profile</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">User Settings</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4">
                Log Out
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Container>
      </Navbar>
    
      <Container>
        <Row>
        <Col sm md lg xl xxl={6}>
          <h2 className='mt-4'>Hi, Welcome to Signite </h2>
          <h4 className='mt-4'>Please Validate Your Mobile Number</h4>
          <p className='mt-4'>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
          <h4 className='mt-4'>Confirm Your Registration</h4>
          <h5 className='mt-4'>Verify Your Mobile Number</h5>
          <h5 className='mt-4'>Enter The 4-Digit OTP Sent To +91 9XXXX XX231
          <svg
            fill="#F65526"
            width="20px"
            height="20px"
            viewBox="0 0 36 36"
            className='mx-2'
          >
            <title>{"edit-line"}</title>
            <path
              className="clr-i-outline clr-i-outline-path-1"
              d="M33.87,8.32,28,2.42a2.07,2.07,0,0,0-2.92,0L4.27,23.2l-1.9,8.2a2.06,2.06,0,0,0,2,2.5,2.14,2.14,0,0,0,.43,0L13.09,32,33.87,11.24A2.07,2.07,0,0,0,33.87,8.32ZM12.09,30.2,4.32,31.83l1.77-7.62L21.66,8.7l6,6ZM29,13.25l-6-6,3.48-3.46,5.9,6Z"
            />
            <rect x={0} y={0} width={36} height={36} fillOpacity={0} />
          </svg>
          </h5>
          <Row className='mt-4'>
            <Col sm md lg xl xxl>
              <InputGroup size="lg">
                <Form.Control
                  aria-label="Large"
                  aria-describedby="inputGroup-sizing-sm"
                  className='px-4'
                />
              </InputGroup>
            </Col>
            <Col sm md lg xl xxl>
              <InputGroup size="lg">
                <Form.Control
                  aria-label="Large"
                  aria-describedby="inputGroup-sizing-sm"
                  className='px-4'
                />
              </InputGroup>
            </Col>
            <Col sm md lg xl xxl>
              <InputGroup size="lg">
                <Form.Control
                  aria-label="Large"
                  aria-describedby="inputGroup-sizing-sm"
                  className='px-4'
                />
              </InputGroup>
            </Col>
            <Col sm md lg xl xxl>
              <InputGroup size="lg">
                <Form.Control
                  aria-label="Large"
                  aria-describedby="inputGroup-sizing-sm"
                  className='px-4'
                />
              </InputGroup>
            </Col>
            <Col sm md lg xl xxl></Col>
            <Col sm md lg xl xxl></Col>
            <Col sm md lg xl xxl></Col>
            <Col sm md lg xl xxl></Col>
          </Row>
          <Row>
            <Col sm md lg xl xxl={6} className='pt-5'>
              <Button 
              className="btn-block mr-1 mt-1 btn-lg btn-custom"
              color="primary"
              block
              fluid>Verify OTP</Button>
            </Col>
           </Row>   
        </Col>
        <Col sm md lg xl xxl={6}>
          <Image
            src={bg}
            alt="UserName profile image"
            roundedCircle
          />
        </Col>
        </Row>
      </Container>
    </Fragment>
  );
}

const UserMenu = (
  <Image
    src={'https://github.com/mshaaban0.png'}
    alt="UserName profile image"
    roundedCircle
    style={{ width: '40px' }}
    title='John'
  />
)

export default App;
